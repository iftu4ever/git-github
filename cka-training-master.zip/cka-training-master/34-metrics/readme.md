### Apply the following manifest.
[Metrics Server](https://gitlab.platform-engineering.com/container-guild/cka/-/blob/master/metrics-server.yaml)

### Use `kubectl top` to:

- Find the pod that is using the most cpu/memory.

- Find the node that has the highest cpu/memory usage.

