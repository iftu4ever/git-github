## Work Through the Kubectl Cheatsheet
### Familiarise yourself with the Docs
- Pods
- Deployments
- Services

### Explore Kubectl features with the resources that you have created 

- -o wide
- -o custom-columns
- -o json
- --namespace
- --sort-by
- --selector
- logs
- exec 
- events

