Create a Daemonset using: 
Image = `nginx:latest`
Namespace = `mydaemonset`

**Verify the DaemonSet has deployed correctly**
