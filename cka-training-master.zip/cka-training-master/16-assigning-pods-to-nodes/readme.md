## Work through the Kubernetes docs on “assigning pods to nodes”
### Aims: 
    nodeSelector
    Node affinity
    Pod affinity
    nodeName
