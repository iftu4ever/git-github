### Create an nginx Pod that creates an environment variable ilike from the favorite key from the colors ConfigMap

### Amend the pod spec to export all the variables from the ConfigMap as environment variables

### Create another ConfigMap using Yaml
