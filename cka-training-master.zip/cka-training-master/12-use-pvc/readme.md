Create a new deployment to use the pvc 

    image = nginx

Mount the PVC to `/usr/share/nginx/html/` of the pod
Access the deployment from your *laptop*
