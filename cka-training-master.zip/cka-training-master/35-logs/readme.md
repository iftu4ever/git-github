### View the logs for the Kubernetes API server.

### Use `kubectl logs` to:

- Show the logs for the Kubernetes API server.

```
kubectl get po -n kube-system
kubectl logs kube-apiserver-xxx -n kube-system
```
