Copy previous job file to a new file

Edit the new file so that it is a cronjob that runs every 2 mins
