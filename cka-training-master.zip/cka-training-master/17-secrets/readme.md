### Create a secret
#### Export as an environment variable into a pod 
#### Mount as a file into a pod
